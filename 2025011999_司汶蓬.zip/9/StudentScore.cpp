#include "StudentScore.h"
#include <iomanip>
#include <sstream>

using namespace std;

// ���캯��ʵ��
StudentScore::StudentScore() : studentId(""), score(0.0) {}

StudentScore::StudentScore(const string& id, double s)
    : studentId(id), score(s) {
}

// ��ȡѧ��
string StudentScore::getId() const {
    return studentId;
}

// ��ȡ�ɼ�
double StudentScore::getScore() const {
    return score;
}

// ���óɼ�
void StudentScore::setScore(double s) {
    score = s;
}

// ��ʾѧ����Ϣ
void StudentScore::display() const {
    cout << "ѧ��: " << studentId << ", �ɼ�: "
        << fixed << setprecision(2) << score << endl;
}

// ת��Ϊ�ļ��洢��ʽ
string StudentScore::toFileFormat() const {
    return studentId + "," + to_string(score);
}

// ���ļ���ʽ����
StudentScore StudentScore::fromFileFormat(const string& line) {
    size_t commaPos = line.find(',');
    if (commaPos == string::npos) {
        return StudentScore();
    }
    string id = line.substr(0, commaPos);
    double s = stod(line.substr(commaPos + 1));
    return StudentScore(id, s);
}